Contact Informaiton

-------------------

Authors: David YeounJun Park, Haodong Huang

User ID: y27park, h53huang

Student Number: 20434264, 20442592



General Usage Notes

-------------------
- This program prints out the number of active tasks at an interval.
- The helloworld.c, rt_Task.c, and Lab0b questions.docx files contain the code and answer to the questions.


Installation and Run

-------------------

1. Download the file archive.

2. Unzip the file archive.

3. Open Keil uVision and navigate to the Lab0b folder

4. Open helloworld_rtxlib.uvmpw

5. Select HelloWorld RAM from the dropdown box

6. Project -> Batch Build, select all and press build.

7. Debug -> Start/stop debug session

8. Press F5 or Run

9. Open PuTTY, select serial and set the speed to 115200

10. Select open and the terminal window will print out the number of tasks and task number.



