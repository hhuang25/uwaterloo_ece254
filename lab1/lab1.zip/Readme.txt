rt_user.c ver. 1.0 30/10/2013
rt_user.h ver. 1.0 30/10/2013
lab1_main.c ver. 1.0 30/10/2013

Contact Informaiton
-------------------
Authors: David YeounJun Park, Haodong Huang
User ID: y27park, h53huang
Student Number: 20434264, 20442592

General Usage Notes
-------------------
- rt_user.c is the main file that contains the code
- rt_user.h is the header file that contains wrapping
- lab1_main.c is the main file that contains the testing suite

Building Project
-------------------
1) Open the project file with Keil uVision4.
2) Build the whole project with the build button. Make sure that every project is selected.

Running Project
-------------------
There are two ways to run the project. One is to use simulator the other to actual board.
(Using Simulator)
1) From Select Target dropdown box, select HelloWorld SIM.
2) Click debugging button and enter into debugging mode.
3) Run the code.
(Using the actual board)
1) Open putty.exe and connect to the board. Details are provided in the lab amnual.
2) From Select Target dropbown box, select HelloWorld RAM.
3) Click debugging button and enter into debugging mode.
4) Run the code.

Copyright 2013 University of Waterloo. All rights reserved.