ListOfFiles ver. 1.0 09/17/2013

Contact Informaiton
-------------------
Authors: David YeounJun Park, Haodong Huang
User ID: y27park, h53huang
Student Number: 20434264, 20442592

General Usage Notes
-------------------
- This program tells the user files in the current directory.
- This program will print name, type, user id, group id, size, date last accessed, date created, date last modified, and permission of the items in the current directory.

Installation
-------------------
1. Download the file archive.
2. Unzip the file archive.
3. Move in to the folder.
4. Type Make.
5. A .out file called "List.out" will be generated. Move "List.out" to the folder user want to use.
6. Execute the file by typing ./List.out.
7. Linux system will display the file information.

Copyright 2013 University of Waterloo. All rights reserved.